	1. RESEARCH QUESTION DESCRIPTION
		URI         : http://risis.eu/activity/idea_2fedae
		DESCRIPTION : How to predict university ranks based on the university’s characteristics and environment? (NETHERLAND EXAMPLE)

	2. VIEWS CREATED

		View_Lens 1: http://risis.eu/view/View_P362596126

			DATASET: http://risis.eu/lens/union_Eter_2014_Grid_20180501_NL_P1321215137
			DATASET: http://risis.eu/lens/union_LeidenRanking_2015_Eter_2014_N1798631176
			DATASET: http://risis.eu/linkset/eter_2014_eter_2014_enriched_identity_University_N1146516762
			DATASET: http://risis.eu/linkset/grid_20180501_NL_grid_20180501_enriched_identity_Organization_P1996470822

				Filter for dataset: http://risis.eu/dataset/eter_2014
					Property: http://risis.eu/dataset/eter_2014
					Property: http://risis.eu/eter_2014/ontology/class/University
					Property: http://risis.eu/eter_2014/ontology/predicate/Institution_Name

				Filter for dataset: http://risis.eu/dataset/grid_20180501_NL
					Property: http://risis.eu/dataset/grid_20180501_NL
					Property: http://www.w3.org/2000/01/rdf-schema#label
					Property: http://xmlns.com/foaf/0.1/Organization

				Filter for dataset: http://risis.eu/dataset/grid_20180501_enriched
					Property: http://risis.eu/alignment/predicate/typeCount
					Property: http://risis.eu/dataset/grid_20180501_enriched
					Property: http://xmlns.com/foaf/0.1/Organization

				Filter for dataset: http://risis.eu/dataset/leidenRanking_2015
					Property: http://risis.eu/dataset/leidenRanking_2015
					Property: http://risis.eu/leidenRanking_2015/ontology/class/University
					Property: http://risis.eu/leidenRanking_2015/ontology/predicate/actor

	3. LINKSETS CREATED FROM AN ALIGNMENT MAPPING
		PREFIX ls:<http://risis.eu/linkset/> 
		There are 8 linksets
			LINKSET      1/8       65 triples in ls:leidenRanking_2015_eter_2014_exactStrSim_University_actor_N2004882188
			LINKSET      2/8      350 triples in ls:leidenRanking_2015_eter_2014_exactStrSim_University_actor_P1194098727
			LINKSET      3/8        2 triples in ls:eter_2014_grid_20180501_NL_exactStrSim_University_English_Institution_Name_N1882185496
			LINKSET      4/8        3 triples in ls:eter_2014_grid_20180501_NL_exactStrSim_University_Institution_Name_P103189843
			LINKSET      5/8       39 triples in ls:eter_2014_grid_20180501_NL_exactStrSim_University_English_Institution_Name_N842942632
			LINKSET      6/8        7 triples in ls:eter_2014_grid_20180501_NL_exactStrSim_University_Institution_Name_P1910297649
			LINKSET      7/8     2624 triples in ls:eter_2014_eter_2014_enriched_identity_University_N1146516762
			LINKSET      8/8     1360 triples in ls:grid_20180501_NL_grid_20180501_enriched_identity_Organization_P1996470822

	4. LENSES CREATED FROM AN ALIGNMENT MAPPING
		PREFIX lens:<http://risis.eu/linkset/>
		There are 2 lenses
			LENS         1/2      360 triples : lens:union_LeidenRanking_2015_Eter_2014_N1798631176
			LENS         2/2       46 triples : lens:union_Eter_2014_Grid_20180501_NL_P1321215137
